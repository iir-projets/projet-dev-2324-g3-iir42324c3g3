package com.example.gestion_companies_aeriennes_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionCompaniesAeriennesBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
